package com.deloitte.library.services;

import com.deloitte.library.model.Books;

public interface BooksInterface {
 public void insertBook(String bookName, String author, int price);

}
