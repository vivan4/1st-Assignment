<?php
include("config.php");

if($_SESSION["is_login"]=="" or !isset($_SESSION['is_login']))
{
    header("location:index.php");
}
?>
<?php
$cid=$_REQUEST['did'];
$sql="delete from contact_tbl where cid='$cid'";
mysqli_query($cn,$sql);
header("location:viewcontact.php");
?>