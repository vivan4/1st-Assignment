 <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Dashboard</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-mobile-phone fa-5x"></i>
                                    </div>
									
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"></div>
                                        <div>Reviews</div>
                                        <div><font size="5"><?php
                                            $sql3="select * from review_tbl";
                                      $rs3=mysqli_query($cn,$sql3);
                                      $n = mysqli_num_rows($rs3);
                                     echo $n;
                                      ?>
                                  </font>
                                  </div>
                                    </div>
                                </div>
                            </div>
                            <a href="viewreview.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Reviews</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                   

                                 
                                    
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-shopping-cart fa-5x"></i>
                                    </div>
									
									
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"></div>
                                        <div>New Orders</div>
                                        <div><font size="5"> <?php $sql="select * from order_tbl where status_id='1' OR status_id='2'";
                                     $rs=mysqli_query($cn,$sql);
                                     $n = mysqli_num_rows($rs);
                                     echo $n;
                                     ?></font></div>
                                    </div>
                                </div>
                            </div>
                            <a href="vieworders.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View All Orders</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-arrow-circle-right fa-5x"></i>
                                    </div>
									
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"></div>
                                        <div>Total Income</div>
                                        <div><font size="5"><?php $sql2="select SUM(tprice) as total from order_tbl";
                                     $rs2=mysqli_query($cn,$sql2);
                                     $row = mysqli_fetch_array($rs2);
                                     $sum = $row['total'];
                                     echo $sum;
                                      ;
                                     ?>
                                         ₹
                                     </font></div>
                                    </div>
                                </div>
                            </div>
                            <a href="#">
                                <div class="panel-footer">
                                    <span class="pull-left">Including GST and Delivery Charges</span>
                                    

                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                 
         </div>   
        