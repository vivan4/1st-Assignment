<?php
include("config.php");

if($_SESSION["is_login"]=="" or !isset($_SESSION['is_login']))
{
    header("location:index.php");
}
$did=$_REQUEST['did'];
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$scat_name=$_REQUEST['name'];
$category_id=$_REQUEST['category'];
$sql="update subcategory_tbl set scat_name='".$scat_name."',category_id='".$category_id."'
where scat_id=".$did."";
mysqli_query($cn,$sql);
}
$sql1 = "select * from subcategory_tbl where scat_id='".$did."'";
$rs = mysqli_query($cn,$sql1);
$d = mysqli_fetch_array($rs);
?>

<!--=======================================DOCTYPE html=============================================-->

<html lang="en">
    <head><title>Grocercart.com/Admin</title>
      <script>
        function goback()
        {
          window.history.back();
        }
 function validate()
      {
      
         if( document.f1.name.value == "" )
         {
            alert( "Please Provide Sub-Category Name!" );
            document.f1.name.focus() ;
            return false;
         }     
    
         return( true );
      }
   
</script>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content=""> 

        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="css/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

        
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        
        
        
        
          
    </head>
    
    <body>

        <div id="wrapper">

                <?php include("header.php");?>      
         
                <?php include("sidebar.php");?> 
                
                
  <br/>     
            
       <div id="page-wrapper">
    
           <div class="span10">
            
                        <form class="form-horizontal"  method="post" action="" name="f1" onSubmit="return(validate());">
                                     
                          <fieldset>
                                   <div class="alert alert-success">
                                      <h3>Update Sub-Categories Details</h3>
                        	       </div>
  
          <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Sub-Category Name</strong></label>
                 <div class="controls">
                    <input type="text" id="inputError" name="name" value="<?php echo $d['scat_name'];?>">
                 </div>
        </div>
         <!--Design for combo box-->			 
			 
			 
			 <div class="control-group success">
              <label for="inputError" class="control-label"><strong>Category</strong></label>
                 <div class="controls">
                    <select id="selectError" name="category"> 
                     
                    <?php
                        $sql1="select * from categories_tbl";
                        $rs1=mysqli_query($cn,$sql1);
                        while($data=mysqli_fetch_array($rs1))
                        {
                          ?>
                        <option value="<?php echo $data['category_id'];?>" <?php if($data['category_id']==$d['category_id']){?> selected="selected"<?php }?>>
                            <?php echo $data['category_name'];?>
                        </option>
                        <?php
                        }
                        ?>
                        
                    </select>
                     
                        </div>
                
        </div>       

        <div class="form-actions">                    
        <button type="submit" class="btn btn-success">Update Data</button>                  
        
        
            
            
        </div>                               
            
            </fieldset>
            </form>
        </div>   
        <button type="submit" class="btn btn-danger"  onClick="return(goback())">Go Back</button>        
   </div>  
                                   
            </div>
            
            
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="js/startmin.js"></script>

    </body>
</html>
