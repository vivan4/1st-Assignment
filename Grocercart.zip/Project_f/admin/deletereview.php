<?php
include("config.php");

if($_SESSION["is_login"]=="" or !isset($_SESSION['is_login']))
{
    header("location:index.php");
}
?>
<?php
$review_id=$_REQUEST['did'];
$sql="delete from review_tbl where review_id='$review_id'";
mysqli_query($cn,$sql);
header("location:viewreview.php");
?>