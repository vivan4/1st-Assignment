<?php
include("config.php");

if($_SESSION["is_login"]=="" or !isset($_SESSION['is_login']))
{
    header("location:index.php");
}
$did=$_REQUEST['did'];
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$status=$_REQUEST['status'];
$sql="update order_tbl set status_id='".$status."'
where book_id=".$did."";
mysqli_query($cn,$sql);
}
$sql6 = "select * from order_tbl where book_id='".$did."'";
$rs = mysqli_query($cn,$sql6);
$d = mysqli_fetch_array($rs);
?>

<!--=======================================DOCTYPE html=============================================-->

<html lang="en">
    <head><title>Grocercart.com/Admin</title>
        <script>
            function goback()
        {
          window.history.back();
        }
        </script>    
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content=""> 

        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="css/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

        
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        
        
        
        
          
    </head>
    
    <body>

        <div id="wrapper">

                <?php include("header.php");?>      
         
                <?php include("sidebar.php");?> 
                
                
  <br/>     
            
       <div id="page-wrapper">
    
           <div class="span10">
            
                        <form class="form-horizontal"  method="post">
                                     
                          <fieldset>
                                   <div class="alert alert-success">
                                      <h3>Update Booking Details</h3>
                        	       </div>
       <div class="control-group success">
              <label class="control-label" for="inputError"><strong>User Name</strong></label>
                 <div class="controls">
                    <input type="text" id="inputError" name="name" 
                    value="<?php $sql2="select * from user_tbl where user_id=".$d['user_id']."";
                                      $rs2=mysqli_query($cn,$sql2);
									  $d2=mysqli_fetch_array($rs2);
									   echo $d2['name'];?>" readonly>
                 </div>
        </div>
        
         <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Product Name</strong></label>
                 <div class="controls">
                    <input type="text" id="inputError" name="name" 
                    value="<?php $sql3="select * from product_tbl where product_id=".$d['product_id']."";
											$rs3=mysqli_query($cn,$sql3);
											$d3=mysqli_fetch_array($rs3);
											 echo $d3['product_name'];?>" readonly>
                 </div>
        </div>
        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Sub-Category</strong></label>
                 <div class="controls">
                    <input type="text" id="inputError" name="name" 
                    value="<?php $sql4="select * from subcategory_tbl where scat_id=".$d['scat_id']."";
                                            $rs4=mysqli_query($cn,$sql4);
                                            $d4=mysqli_fetch_array($rs4);
                                             echo $d4['scat_name'];?>" readonly>
                 </div>
        </div>
        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Category</strong></label>
                 <div class="controls">
                    <input type="text" id="inputError" name="name" 
                    value="<?php $sql5="select * from categories_tbl where category_id=".$d['category_id']."";
                                            $rs5=mysqli_query($cn,$sql5);
                                            $d5=mysqli_fetch_array($rs5);
                                             echo $d5['category_name'];?>" readonly>
                 </div>
        </div>
        
         <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Address</strong></label>
                 <div class="controls">
                    <input type="text" id="inputError" name="name" value="<?php echo $d['address'];?>" readonly>
                 </div>
        </div>
         <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Quantity</strong></label>
                 <div class="controls">
                    <input type="text" id="inputError" name="name" value="<?php echo $d['quantity'];?>" readonly>
                 </div>
        </div>
         <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Total Price</strong></label>
                 <div class="controls">
                    <input type="text" id="inputError" name="name" value="<?php echo $d['tprice'];?>" readonly>
                 </div>
        </div> 
        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Date</strong></label>
                 <div class="controls">
                    <input type="text" id="inputError" name="name" value="<?php echo $d['date1'];?>" readonly>
                 </div>
        </div>
         <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Time</strong></label>
                 <div class="controls">
                    <input type="text" id="inputError" name="name" value="<?php echo $d['time1'];?>" readonly>
                 </div>
        </div>
         <!--Design for combo box-->			 
			 
			 
			 <div class="control-group success">
              <label for="inputError" class="control-label"><strong>Status</strong></label>
                 <div class="controls">
                    <select id="selectError" name="status"> 
                     
                    <?php
                        $sql1="select * from status_tbl";
                        $rs1=mysqli_query($cn,$sql1);
                        while($data=mysqli_fetch_array($rs1))
                        {
                          ?>
                        <option value="<?php echo $data['status_id'];?>" <?php if($data['status_id']==$d['status_id']){?> selected="selected"<?php }?>>
                            <?php echo $data['status'];?>
                        </option>
                        <?php
                        }
                        ?>
                        
                    </select>
                     
                        </div>
                
        </div>       

        <div class="form-actions">                    
        <button type="submit" class="btn btn-success" onClick="return alert('DATA UPDATED SUCCESSFULLY')">Update Data</button>                  
        
        
            
            
        </div>                               
            
            </fieldset>
            </form>
        </div>   
               <button type="submit" class="btn btn-danger"  onClick="return(goback())">Go Back</button> 
   </div>  
                                   
            </div>
            
            
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="js/startmin.js"></script>

    </body>
</html>
