<?php
include("config.php");
$_SESSION['is_login']="";
header("location:index.php");
?>
