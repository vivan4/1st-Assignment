<?php
include("config.php");

if($_SESSION["is_login"]=="" or !isset($_SESSION['is_login']))
{
    header("location:index.php");
}
?>
<?php
$about_id=$_REQUEST['did'];
$sql="delete from about_tbl where about_id='$about_id'";
mysqli_query($cn,$sql);
header("location:viewabout.php");
?>