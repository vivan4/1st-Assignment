v<?php
include("config.php");

if($_SESSION["is_login"]=="" or !isset($_SESSION['is_login']))
{
    header("location:index.php");
}
?>
<?php
$home_id=$_REQUEST['did'];
$sql="delete from home_tbl where home_id='$home_id'";
mysqli_query($cn,$sql);
header("location:viewhome.php");
?>