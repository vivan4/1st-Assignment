<?php
session_start();
$cn=mysqli_connect("localhost","root","","grocery_db");
define("SITE_TITLE","Grocery.com");

?>