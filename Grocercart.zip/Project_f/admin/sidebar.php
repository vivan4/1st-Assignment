<div class="navbar-default sidebar" role="navigation">
             <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                            
                            <li>
                                <a href="dashboard.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                            </li>
                           <li>
             <a href="#"><i class="fa fa-home fa-fw"></i>Home<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="addhome.php">Add Home</a>
                                    </li>
                                    <li>
                                        <a href="viewhome.php">View Home</a>
                                    </li>
                                </ul>
							
								</li>
                                
							
								
							 <li>
             <a href="#"><i class="fa fa-info-circle fa-fw"></i>About Us<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="addabout.php">Add About</a>
                                    </li>
                                    <li>
                                        <a href="viewabout.php">View About</a>
                                    </li>
                                </ul>
							
								</li>
													
							 <li>
             <a href="#"><i class="fa fa-phone fa-fw"></i> Contact Us<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="addcontact.php">Add Contact</a>
                                    </li>
                                    <li>
                                        <a href="viewcontact.php">View Contact</a>
                                    </li>
                                </ul>
							
								</li>
                                
                                
														
								  
                                
                                
                 <li>
            <a href="#"><i class="fa fa-list fa-fw"></i>Categories<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="addcategories.php">Add Categories</a>
                                    </li>
                                    <li>
                                        <a href="viewcategories.php">View Categories</a>
                                    </li>
                                </ul>
							
								</li>
                
				
				
				 <li>
             <a href="#"><i class="fa fa-list-alt fa-fw"></i>Sub Categories<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="addsubcategories.php">Add  Sub-Categories</a>
                                    </li>
                                    <li>
                                        <a href="viewsubcategories.php">View Sub-Categories</a>
                                    </li>
                                </ul>
							
								</li>
                <li>
            <a href="#"><i class="fa fa-shopping-cart fa-fw"></i>Products<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="addproduct.php">Add Product</a>
                                    </li>
                                    <li>
                                        <a href="viewproduct.php">View Product</a>
                                    </li>
                                     
                           
                                </ul>
							
								</li>                 
                               
                
								
								
                         </div>
                    <!-- /.sidebar-collapse -->
                </div>
        